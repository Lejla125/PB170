EESchema Schematic File Version 4
EELAYER 30 0
EELAYER END
$Descr A4 11693 8268
encoding utf-8
Sheet 3 7
Title ""
Date ""
Rev ""
Comp ""
Comment1 ""
Comment2 ""
Comment3 ""
Comment4 ""
$EndDescr
Text GLabel 8550 2400 2    50   Input ~ 0
GND
Text GLabel 7550 2400 0    50   Input ~ 0
VCC
Wire Wire Line
	8400 3500 8550 3500
Wire Wire Line
	7550 3500 7700 3500
Wire Wire Line
	3150 4550 4300 4550
Wire Wire Line
	5550 3550 5950 3550
Wire Wire Line
	5500 4100 6000 4100
Wire Wire Line
	4400 4550 5450 4550
Text HLabel 4900 3550 1    50   Input ~ 0
nQ1Q2
$Comp
L PB170:74HC08 U10
U 5 1 60232578
P 8050 1800
F 0 "U10" H 8280 1846 50  0000 L CNN
F 1 "74HC08" H 8280 1755 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 8050 1800 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC08D-653_C5593.pdf" H 8050 1800 50  0001 C CNN
F 4 "C5593" H 8050 1800 50  0001 C CNN "LCSC"
	5    8050 1800
	0    -1   -1   0   
$EndComp
Wire Wire Line
	4850 4100 5400 4100
$Comp
L PB170:74HC08 U10
U 2 1 6022D13B
P 6000 3800
F 0 "U10" V 5979 3930 50  0000 L CNN
F 1 "74HC08" V 6070 3930 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 6000 3800 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC08D-653_C5593.pdf" H 6000 3800 50  0001 C CNN
F 4 "C5593" H 6000 3800 50  0001 C CNN "LCSC"
	2    6000 3800
	0    1    1    0   
$EndComp
Text GLabel 4350 5750 3    50   Input ~ 0
GND
Text HLabel 3450 2550 1    50   Input ~ 0
I1
$Comp
L PB170:74HC08 U9
U 1 1 603CAEA8
P 3750 3350
F 0 "U9" V 3729 3480 50  0000 L CNN
F 1 "74HC08" V 3820 3480 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 3750 3350 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC08D-653_C5593.pdf" H 3750 3350 50  0001 C CNN
F 4 "C5593" H 3750 3350 50  0001 C CNN "LCSC"
	1    3750 3350
	0    1    1    0   
$EndComp
$Comp
L PB170:74HC08 U9
U 2 1 603CCDA7
P 2850 3800
F 0 "U9" V 2829 3930 50  0000 L CNN
F 1 "74HC08" V 2920 3930 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 2850 3800 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC08D-653_C5593.pdf" H 2850 3800 50  0001 C CNN
F 4 "C5593" H 2850 3800 50  0001 C CNN "LCSC"
	2    2850 3800
	0    1    1    0   
$EndComp
Text HLabel 2800 3550 1    50   Input ~ 0
I2
Text HLabel 2900 3550 1    50   Input ~ 0
Q1nQ2
Text HLabel 3350 3650 1    50   Input ~ 0
I1I2I3
Wire Wire Line
	3200 4100 3400 4100
Wire Wire Line
	8550 2650 8550 1800
Wire Wire Line
	8550 3500 8550 2650
Connection ~ 8550 2650
Wire Wire Line
	7550 2650 7550 3500
Wire Wire Line
	7550 1800 7550 2650
Connection ~ 7550 2650
$Comp
L PB170:74HC08 U9
U 5 1 603D1356
P 8050 2650
F 0 "U9" H 8280 2696 50  0000 L CNN
F 1 "74HC08" H 8280 2605 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 8050 2650 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC08D-653_C5593.pdf" H 8050 2650 50  0001 C CNN
F 4 "C5593" H 8050 2650 50  0001 C CNN "LCSC"
	5    8050 2650
	0    -1   -1   0   
$EndComp
$Comp
L PB170:74HC08 U9
U 4 1 603D03AF
P 4850 3800
F 0 "U9" V 4829 3930 50  0000 L CNN
F 1 "74HC08" V 4920 3930 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 4850 3800 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC08D-653_C5593.pdf" H 4850 3800 50  0001 C CNN
F 4 "C5593" H 4850 3800 50  0001 C CNN "LCSC"
	4    4850 3800
	0    1    1    0   
$EndComp
$Comp
L PB170:74HC08 U9
U 3 1 603CDE88
P 3500 2800
F 0 "U9" V 3479 2930 50  0000 L CNN
F 1 "74HC08" V 3570 2930 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 3500 2800 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC08D-653_C5593.pdf" H 3500 2800 50  0001 C CNN
F 4 "C5593" H 3500 2800 50  0001 C CNN "LCSC"
	3    3500 2800
	0    1    1    0   
$EndComp
$Comp
L PB170:74HC32 G?
U 5 1 603C08B3
P 8050 3200
AR Path="/603C08B3" Ref="G?"  Part="5" 
AR Path="/603B7AAD/603C08B3" Ref="G2"  Part="5" 
F 0 "G2" H 7928 3246 50  0000 L CNN
F 1 "74HC32" H 7928 3155 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 7500 3400 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC32D-653_C5632.pdf" H 7500 3400 50  0001 C CNN
F 4 "C5632" H 8050 3200 50  0001 C CNN "LCSC"
	5    8050 3200
	0    -1   -1   0   
$EndComp
$Comp
L PB170:74HC32 G?
U 2 1 603BD817
P 3150 4350
AR Path="/603BD817" Ref="G?"  Part="2" 
AR Path="/603B7AAD/603BD817" Ref="G2"  Part="2" 
F 0 "G2" V 3079 4488 50  0000 L CNN
F 1 "74HC32" V 3170 4488 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 2600 4550 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC32D-653_C5632.pdf" H 2600 4550 50  0001 C CNN
F 4 "C5632" H 3150 4350 50  0001 C CNN "LCSC"
	2    3150 4350
	0    1    1    0   
$EndComp
$Comp
L Device:LED G?
U 1 1 603BD80F
P 4350 5450
AR Path="/603BD80F" Ref="G?"  Part="1" 
AR Path="/603B7AAD/603BD80F" Ref="G1"  Part="1" 
F 0 "G1" V 4389 5332 50  0000 R CNN
F 1 "LED" V 4298 5332 50  0000 R CNN
F 2 "PB170:LED0603-R-RD" H 4350 5450 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Everlight-Elec-19-217-GHC-YR1S2-3T_C72043.pdf" H 4350 5450 50  0001 C CNN
F 4 "C72043" H 4350 5450 50  0001 C CNN "LCSC"
	1    4350 5450
	0    -1   -1   0   
$EndComp
$Comp
L Device:R R?
U 1 1 603BD808
P 4350 5150
AR Path="/603BD808" Ref="R?"  Part="1" 
AR Path="/603B7AAD/603BD808" Ref="R2"  Part="1" 
F 0 "R2" H 4420 5196 50  0000 L CNN
F 1 "180R" H 4420 5105 50  0000 L CNN
F 2 "PB170:R0603" V 4280 5150 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Uniroyal-Elec-0603WAF1800T5E_C22828.pdf" H 4350 5150 50  0001 C CNN
F 4 "C22828" H 4350 5150 50  0001 C CNN "LCSC"
	1    4350 5150
	1    0    0    -1  
$EndComp
Wire Wire Line
	4350 5600 4350 5750
$Comp
L PB170:74HC32 G?
U 1 1 603BD7FA
P 4350 4800
AR Path="/603BD7FA" Ref="G?"  Part="1" 
AR Path="/603B7AAD/603BD7FA" Ref="G2"  Part="1" 
F 0 "G2" V 4279 4938 50  0000 L CNN
F 1 "74HC32" V 4370 4938 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 3800 5000 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC32D-653_C5632.pdf" H 3800 5000 50  0001 C CNN
F 4 "C5632" H 4350 4800 50  0001 C CNN "LCSC"
	1    4350 4800
	0    1    1    0   
$EndComp
$Comp
L PB170:74HC32 G?
U 4 1 603BD7F2
P 3400 3900
AR Path="/603BD7F2" Ref="G?"  Part="4" 
AR Path="/603B7AAD/603BD7F2" Ref="G2"  Part="4" 
F 0 "G2" V 3329 4038 50  0000 L CNN
F 1 "74HC32" V 3420 4038 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 2850 4100 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC32D-653_C5632.pdf" H 2850 4100 50  0001 C CNN
F 4 "C5632" H 3400 3900 50  0001 C CNN "LCSC"
	4    3400 3900
	0    1    1    0   
$EndComp
$Comp
L PB170:74HC32 G?
U 3 1 603BD7EB
P 5450 4350
AR Path="/603BD7EB" Ref="G?"  Part="3" 
AR Path="/603B7AAD/603BD7EB" Ref="G2"  Part="3" 
F 0 "G2" V 5379 4488 50  0000 L CNN
F 1 "74HC32" V 5470 4488 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 4900 4550 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC32D-653_C5632.pdf" H 4900 4550 50  0001 C CNN
F 4 "C5632" H 5450 4350 50  0001 C CNN "LCSC"
	3    5450 4350
	0    1    1    0   
$EndComp
$Comp
L PB170:74HC08 U10
U 1 1 6022C7E2
P 5550 3250
F 0 "U10" V 5529 3380 50  0000 L CNN
F 1 "74HC08" V 5620 3380 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 5550 3250 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC08D-653_C5593.pdf" H 5550 3250 50  0001 C CNN
F 4 "C5593" H 5550 3250 50  0001 C CNN "LCSC"
	1    5550 3250
	0    1    1    0   
$EndComp
Text HLabel 5600 3000 1    50   Input ~ 0
Q2
Wire Wire Line
	3450 3650 3750 3650
Wire Wire Line
	3500 3100 3700 3100
Text HLabel 3550 2550 1    50   Input ~ 0
nI3
Text HLabel 3800 3100 1    50   Input ~ 0
nQ2
Text HLabel 4800 3550 1    50   Input ~ 0
nI2I3
Text HLabel 6050 3550 1    50   Input ~ 0
nI2I3
Text HLabel 5500 3000 1    50   Input ~ 0
I1
Wire Wire Line
	2850 4100 3100 4100
$EndSCHEMATC
