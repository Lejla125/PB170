EESchema Schematic File Version 4
EELAYER 30 0
EELAYER END
$Descr A4 11693 8268
encoding utf-8
Sheet 2 7
Title ""
Date ""
Rev ""
Comp ""
Comment1 ""
Comment2 ""
Comment3 ""
Comment4 ""
$EndDescr
$Comp
L Device:LED B?
U 1 1 6036EC8F
P 4950 4100
AR Path="/6036EC8F" Ref="B?"  Part="1" 
AR Path="/6036A600/6036EC8F" Ref="B1"  Part="1" 
F 0 "B1" V 4989 3982 50  0000 R CNN
F 1 "LED" V 4898 3982 50  0000 R CNN
F 2 "PB170:LED0603-R-RD" H 4950 4100 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Everlight-Elec-19-217-BHC-ZL1M2RY-3T_C72041.pdf" H 4950 4100 50  0001 C CNN
F 4 "C72041" H 4950 4100 50  0001 C CNN "LCSC"
	1    4950 4100
	0    -1   -1   0   
$EndComp
$Comp
L Device:R R?
U 1 1 6036EC96
P 4950 3800
AR Path="/6036EC96" Ref="R?"  Part="1" 
AR Path="/6036A600/6036EC96" Ref="R4"  Part="1" 
F 0 "R4" H 5020 3846 50  0000 L CNN
F 1 "180R" H 5020 3755 50  0000 L CNN
F 2 "PB170:R0603" V 4880 3800 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Uniroyal-Elec-0603WAF1800T5E_C22828.pdf" H 4950 3800 50  0001 C CNN
F 4 "C22828" H 4950 3800 50  0001 C CNN "LCSC"
	1    4950 3800
	1    0    0    -1  
$EndComp
Wire Wire Line
	4950 4250 4950 4400
$Comp
L PB170:74HC32 B?
U 1 1 6036ECA4
P 4950 3450
AR Path="/6036ECA4" Ref="B?"  Part="1" 
AR Path="/6036A600/6036ECA4" Ref="B2"  Part="1" 
F 0 "B2" V 4879 3588 50  0000 L CNN
F 1 "74HC32" V 4970 3588 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 4400 3650 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC32D-653_C5632.pdf" H 4400 3650 50  0001 C CNN
F 4 "C5632" H 4950 3450 50  0001 C CNN "LCSC"
	1    4950 3450
	0    1    1    0   
$EndComp
$Comp
L PB170:74HC32 B?
U 2 1 6036ECAB
P 4200 3000
AR Path="/6036ECAB" Ref="B?"  Part="2" 
AR Path="/6036A600/6036ECAB" Ref="B2"  Part="2" 
F 0 "B2" V 4129 3138 50  0000 L CNN
F 1 "74HC32" V 4220 3138 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 3650 3200 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC32D-653_C5632.pdf" H 3650 3200 50  0001 C CNN
F 4 "C5632" H 4200 3000 50  0001 C CNN "LCSC"
	2    4200 3000
	0    1    1    0   
$EndComp
$Comp
L PB170:74HC32 B?
U 3 1 6036ECB2
P 5800 3000
AR Path="/6036ECB2" Ref="B?"  Part="3" 
AR Path="/6036A600/6036ECB2" Ref="B2"  Part="3" 
F 0 "B2" V 5729 3138 50  0000 L CNN
F 1 "74HC32" V 5820 3138 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 5250 3200 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC32D-653_C5632.pdf" H 5250 3200 50  0001 C CNN
F 4 "C5632" H 5800 3000 50  0001 C CNN "LCSC"
	3    5800 3000
	0    1    1    0   
$EndComp
$Comp
L PB170:74HC32 B?
U 4 1 6036ECB9
P 6250 2550
AR Path="/6036ECB9" Ref="B?"  Part="4" 
AR Path="/6036A600/6036ECB9" Ref="B2"  Part="4" 
F 0 "B2" V 6179 2688 50  0000 L CNN
F 1 "74HC32" V 6270 2688 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 5700 2750 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC32D-653_C5632.pdf" H 5700 2750 50  0001 C CNN
F 4 "C5632" H 6250 2550 50  0001 C CNN "LCSC"
	4    6250 2550
	0    1    1    0   
$EndComp
$Comp
L PB170:74HC32 S?
U 3 1 6036ECC2
P 3850 2550
AR Path="/6036ECC2" Ref="S?"  Part="3" 
AR Path="/6036A600/6036ECC2" Ref="S1"  Part="3" 
F 0 "S1" V 3779 2688 50  0000 L CNN
F 1 "74HC32" V 3870 2688 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 3300 2750 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC32D-653_C5632.pdf" H 3300 2750 50  0001 C CNN
F 4 "C5632" H 3850 2550 50  0001 C CNN "LCSC"
	3    3850 2550
	0    1    1    0   
$EndComp
$Comp
L PB170:74HC32 B?
U 5 1 60371505
P 9000 3100
AR Path="/60371505" Ref="B?"  Part="5" 
AR Path="/6036A600/60371505" Ref="B2"  Part="5" 
F 0 "B2" H 8878 3146 50  0000 L CNN
F 1 "74HC32" H 8878 3055 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 8450 3300 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC32D-653_C5632.pdf" H 8450 3300 50  0001 C CNN
F 4 "C5632" H 9000 3100 50  0001 C CNN "LCSC"
	5    9000 3100
	0    -1   -1   0   
$EndComp
Wire Wire Line
	3850 2750 4150 2750
$Comp
L PB170:74HC08 U14
U 1 1 6039A96D
P 3350 2000
F 0 "U14" V 3329 2130 50  0000 L CNN
F 1 "74HC08" V 3420 2130 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 3350 2000 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC08D-653_C5593.pdf" H 3350 2000 50  0001 C CNN
F 4 "C5593" H 3350 2000 50  0001 C CNN "LCSC"
	1    3350 2000
	0    1    1    0   
$EndComp
$Comp
L PB170:74HC08 U14
U 2 1 6039BC7A
P 3300 1450
F 0 "U14" V 3279 1580 50  0000 L CNN
F 1 "74HC08" V 3370 1580 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 3300 1450 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC08D-653_C5593.pdf" H 3300 1450 50  0001 C CNN
F 4 "C5593" H 3300 1450 50  0001 C CNN "LCSC"
	2    3300 1450
	0    1    1    0   
$EndComp
$Comp
L PB170:74HC08 U14
U 3 1 6039C87D
P 4550 2450
F 0 "U14" V 4529 2580 50  0000 L CNN
F 1 "74HC08" V 4620 2580 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 4550 2450 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC08D-653_C5593.pdf" H 4550 2450 50  0001 C CNN
F 4 "C5593" H 4550 2450 50  0001 C CNN "LCSC"
	3    4550 2450
	0    1    1    0   
$EndComp
$Comp
L PB170:74HC08 U14
U 4 1 6039D5D8
P 4600 1900
F 0 "U14" V 4579 2030 50  0000 L CNN
F 1 "74HC08" V 4670 2030 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 4600 1900 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC08D-653_C5593.pdf" H 4600 1900 50  0001 C CNN
F 4 "C5593" H 4600 1900 50  0001 C CNN "LCSC"
	4    4600 1900
	0    1    1    0   
$EndComp
$Comp
L PB170:74HC08 U14
U 5 1 6039E0B7
P 8950 1600
F 0 "U14" H 9180 1646 50  0000 L CNN
F 1 "74HC08" H 9180 1555 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 8950 1600 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC08D-653_C5593.pdf" H 8950 1600 50  0001 C CNN
F 4 "C5593" H 8950 1600 50  0001 C CNN "LCSC"
	5    8950 1600
	0    -1   -1   0   
$EndComp
Text HLabel 3900 2300 1    50   Input ~ 0
I1I2I3
Wire Wire Line
	3350 2300 3800 2300
Text HLabel 3250 1200 1    50   Input ~ 0
I1
Text HLabel 3350 1200 1    50   Input ~ 0
I2
Text HLabel 3400 1750 1    50   Input ~ 0
nQ2
Wire Wire Line
	4200 3200 4900 3200
Text HLabel 4550 1650 1    50   Input ~ 0
I1
Text HLabel 4650 1650 1    50   Input ~ 0
nI2
Text HLabel 4500 2200 1    50   Input ~ 0
Q2
Wire Wire Line
	4250 2750 4550 2750
Wire Wire Line
	5000 3200 5800 3200
$Comp
L PB170:74HC08 U15
U 3 1 603B5C4F
P 5850 2000
F 0 "U15" V 5829 2130 50  0000 L CNN
F 1 "74HC08" V 5920 2130 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 5850 2000 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC08D-653_C5593.pdf" H 5850 2000 50  0001 C CNN
F 4 "C5593" H 5850 2000 50  0001 C CNN "LCSC"
	3    5850 2000
	0    1    1    0   
$EndComp
$Comp
L PB170:74HC08 U15
U 4 1 603B6A7A
P 6650 2000
F 0 "U15" V 6629 2130 50  0000 L CNN
F 1 "74HC08" V 6720 2130 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 6650 2000 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC08D-653_C5593.pdf" H 6650 2000 50  0001 C CNN
F 4 "C5593" H 6650 2000 50  0001 C CNN "LCSC"
	4    6650 2000
	0    1    1    0   
$EndComp
Wire Wire Line
	5400 2750 5750 2750
Text HLabel 5450 2200 1    50   Input ~ 0
Q1Q2
Wire Wire Line
	5850 2750 6250 2750
Wire Wire Line
	5850 2300 6200 2300
Wire Wire Line
	6300 2300 6650 2300
$Comp
L PB170:74HC08 U15
U 1 1 603C6470
P 5550 1450
F 0 "U15" V 5529 1580 50  0000 L CNN
F 1 "74HC08" V 5620 1580 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 5550 1450 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC08D-653_C5593.pdf" H 5550 1450 50  0001 C CNN
F 4 "C5593" H 5550 1450 50  0001 C CNN "LCSC"
	1    5550 1450
	0    1    1    0   
$EndComp
$Comp
L PB170:74HC08 U15
U 2 1 603C76E3
P 6200 1450
F 0 "U15" V 6179 1580 50  0000 L CNN
F 1 "74HC08" V 6270 1580 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 6200 1450 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC08D-653_C5593.pdf" H 6200 1450 50  0001 C CNN
F 4 "C5593" H 6200 1450 50  0001 C CNN "LCSC"
	2    6200 1450
	0    1    1    0   
$EndComp
$Comp
L PB170:74HC08 U15
U 5 1 603CAB9C
P 8950 2450
F 0 "U15" H 9180 2496 50  0000 L CNN
F 1 "74HC08" H 9180 2405 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 8950 2450 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC08D-653_C5593.pdf" H 8950 2450 50  0001 C CNN
F 4 "C5593" H 8950 2450 50  0001 C CNN "LCSC"
	5    8950 2450
	0    -1   -1   0   
$EndComp
Wire Wire Line
	5550 1750 5800 1750
Text HLabel 5500 1200 1    50   Input ~ 0
I2
Text HLabel 5600 1200 1    50   Input ~ 0
I3
Text HLabel 5350 2200 1    50   Input ~ 0
nI2I3
Text HLabel 5900 1750 1    50   Input ~ 0
Q1Q2
Text HLabel 6150 1200 1    50   Input ~ 0
nI1I2
Text HLabel 6250 1200 1    50   Input ~ 0
nI3
Wire Wire Line
	6200 1750 6600 1750
Text HLabel 6700 1750 1    50   Input ~ 0
nQ1nQ2
$Comp
L PB170:74HC08 U13
U 3 1 60255A8F
P 5400 2450
F 0 "U13" V 5379 2580 50  0000 L CNN
F 1 "74HC08" V 5470 2580 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 5400 2450 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC08D-653_C5593.pdf" H 5400 2450 50  0001 C CNN
F 4 "C5593" H 5400 2450 50  0001 C CNN "LCSC"
	3    5400 2450
	0    1    1    0   
$EndComp
Wire Wire Line
	8450 1600 8450 2450
Wire Wire Line
	8450 2450 8450 3400
Wire Wire Line
	8450 3400 8650 3400
Connection ~ 8450 2450
Wire Wire Line
	9450 1600 9450 2450
Wire Wire Line
	9450 2450 9450 3400
Wire Wire Line
	9450 3400 9350 3400
Connection ~ 9450 2450
Text GLabel 8450 2700 0    50   Input ~ 0
VCC
Text GLabel 9450 2700 2    50   Input ~ 0
GND
Text GLabel 4950 4400 3    50   Input ~ 0
GND
$EndSCHEMATC
