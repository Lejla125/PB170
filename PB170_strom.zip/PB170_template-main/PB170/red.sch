EESchema Schematic File Version 4
EELAYER 30 0
EELAYER END
$Descr A4 11693 8268
encoding utf-8
Sheet 6 7
Title ""
Date ""
Rev ""
Comp ""
Comment1 ""
Comment2 ""
Comment3 ""
Comment4 ""
$EndDescr
$Comp
L Device:LED RE1
U 1 1 60230F9D
P 4550 4950
F 0 "RE1" V 4589 4832 50  0000 R CNN
F 1 "LED" V 4498 4832 50  0000 R CNN
F 2 "PB170:LED0603-R-RD" H 4550 4950 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Hubei-KENTO-Elec-KT-0603R_C2286.pdf" H 4550 4950 50  0001 C CNN
F 4 "C2286" H 4550 4950 50  0001 C CNN "LCSC"
	1    4550 4950
	0    -1   -1   0   
$EndComp
$Comp
L Device:R R3
U 1 1 60230FA4
P 4550 4650
F 0 "R3" H 4620 4696 50  0000 L CNN
F 1 "180R" H 4620 4605 50  0000 L CNN
F 2 "PB170:R0603" V 4480 4650 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Uniroyal-Elec-0603WAF1800T5E_C22828.pdf" H 4550 4650 50  0001 C CNN
F 4 "C22828" H 4550 4650 50  0001 C CNN "LCSC"
	1    4550 4650
	1    0    0    -1  
$EndComp
Wire Wire Line
	4550 5100 4550 5250
$Comp
L PB170:74HC32 RE2
U 1 1 60230FB2
P 4550 4300
F 0 "RE2" V 4479 4438 50  0000 L CNN
F 1 "74HC32" V 4570 4438 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 4000 4500 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC32D-653_C5632.pdf" H 4000 4500 50  0001 C CNN
F 4 "C5632" H 4550 4300 50  0001 C CNN "LCSC"
	1    4550 4300
	0    1    1    0   
$EndComp
$Comp
L PB170:74HC32 RE2
U 2 1 60230FB9
P 3700 3850
F 0 "RE2" V 3629 3988 50  0000 L CNN
F 1 "74HC32" V 3720 3988 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 3150 4050 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC32D-653_C5632.pdf" H 3150 4050 50  0001 C CNN
F 4 "C5632" H 3700 3850 50  0001 C CNN "LCSC"
	2    3700 3850
	0    1    1    0   
$EndComp
$Comp
L PB170:74HC32 RE2
U 3 1 60230FC2
P 5450 3850
F 0 "RE2" V 5379 3988 50  0000 L CNN
F 1 "74HC32" V 5470 3988 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 4900 4050 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC32D-653_C5632.pdf" H 4900 4050 50  0001 C CNN
F 4 "C5632" H 5450 3850 50  0001 C CNN "LCSC"
	3    5450 3850
	0    1    1    0   
$EndComp
$Comp
L PB170:74HC32 RE2
U 4 1 60230FC9
P 5400 3400
F 0 "RE2" V 5329 3538 50  0000 L CNN
F 1 "74HC32" V 5420 3538 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 4850 3600 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC32D-653_C5632.pdf" H 4850 3600 50  0001 C CNN
F 4 "C5632" H 5400 3400 50  0001 C CNN "LCSC"
	4    5400 3400
	0    1    1    0   
$EndComp
$Comp
L PB170:74HC32 S1
U 1 1 60230FD0
P 3100 3400
F 0 "S1" V 3029 3538 50  0000 L CNN
F 1 "74HC32" V 3120 3538 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 2550 3600 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC32D-653_C5632.pdf" H 2550 3600 50  0001 C CNN
F 4 "C5632" H 3100 3400 50  0001 C CNN "LCSC"
	1    3100 3400
	0    1    1    0   
$EndComp
$Comp
L PB170:74HC32 RE?
U 5 1 602340D2
P 8700 3900
AR Path="/602340D2" Ref="RE?"  Part="5" 
AR Path="/6022E3C4/602340D2" Ref="RE2"  Part="5" 
F 0 "RE2" H 8578 3946 50  0000 L CNN
F 1 "74HC32" H 8578 3855 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 8150 4100 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC32D-653_C5632.pdf" H 8150 4100 50  0001 C CNN
F 4 "C5632" H 8700 3900 50  0001 C CNN "LCSC"
	5    8700 3900
	0    1    1    0   
$EndComp
Text GLabel 4550 5250 3    50   Input ~ 0
GND
Text HLabel 3750 3600 1    50   Input ~ 0
I1I2I3
$Comp
L PB170:74HC08 U11
U 1 1 60282C97
P 2700 2850
F 0 "U11" V 2679 2980 50  0000 L CNN
F 1 "74HC08" V 2770 2980 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 2700 2850 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC08D-653_C5593.pdf" H 2700 2850 50  0001 C CNN
F 4 "C5593" H 2700 2850 50  0001 C CNN "LCSC"
	1    2700 2850
	0    1    1    0   
$EndComp
$Comp
L PB170:74HC08 U11
U 2 1 60283E2C
P 3150 2300
F 0 "U11" V 3129 2430 50  0000 L CNN
F 1 "74HC08" V 3220 2430 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 3150 2300 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC08D-653_C5593.pdf" H 3150 2300 50  0001 C CNN
F 4 "C5593" H 3150 2300 50  0001 C CNN "LCSC"
	2    3150 2300
	0    1    1    0   
$EndComp
$Comp
L PB170:74HC08 U11
U 3 1 60284E09
P 2250 2150
F 0 "U11" V 2229 2280 50  0000 L CNN
F 1 "74HC08" V 2320 2280 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 2250 2150 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC08D-653_C5593.pdf" H 2250 2150 50  0001 C CNN
F 4 "C5593" H 2250 2150 50  0001 C CNN "LCSC"
	3    2250 2150
	0    1    1    0   
$EndComp
$Comp
L PB170:74HC08 U11
U 4 1 60285950
P 3550 2850
F 0 "U11" V 3529 2980 50  0000 L CNN
F 1 "74HC08" V 3620 2980 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 3550 2850 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC08D-653_C5593.pdf" H 3550 2850 50  0001 C CNN
F 4 "C5593" H 3550 2850 50  0001 C CNN "LCSC"
	4    3550 2850
	0    1    1    0   
$EndComp
$Comp
L PB170:74HC08 U11
U 5 1 602868E9
P 8700 2950
F 0 "U11" V 8333 2950 50  0000 C CNN
F 1 "74HC08" V 8424 2950 50  0000 C CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 8700 2950 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC08D-653_C5593.pdf" H 8700 2950 50  0001 C CNN
F 4 "C5593" H 8700 2950 50  0001 C CNN "LCSC"
	5    8700 2950
	0    1    1    0   
$EndComp
Wire Wire Line
	2250 2600 2650 2600
Text HLabel 3100 2050 1    50   Input ~ 0
I1
Text HLabel 2300 1900 1    50   Input ~ 0
I1
Text HLabel 3200 2050 1    50   Input ~ 0
nI2
Text HLabel 2200 1900 1    50   Input ~ 0
nQ2
Wire Wire Line
	3700 4050 4500 4050
$Comp
L PB170:74HC08 U12
U 2 1 6029A12E
P 3950 2300
F 0 "U12" V 3929 2430 50  0000 L CNN
F 1 "74HC08" V 4020 2430 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 3950 2300 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC08D-653_C5593.pdf" H 3950 2300 50  0001 C CNN
F 4 "C5593" H 3950 2300 50  0001 C CNN "LCSC"
	2    3950 2300
	0    1    1    0   
$EndComp
$Comp
L PB170:74HC08 U12
U 3 1 6029BA90
P 6350 3300
F 0 "U12" V 6329 3430 50  0000 L CNN
F 1 "74HC08" V 6420 3430 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 6350 3300 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC08D-653_C5593.pdf" H 6350 3300 50  0001 C CNN
F 4 "C5593" H 6350 3300 50  0001 C CNN "LCSC"
	3    6350 3300
	0    1    1    0   
$EndComp
$Comp
L PB170:74HC08 U12
U 4 1 6029C806
P 5750 2850
F 0 "U12" V 5729 2980 50  0000 L CNN
F 1 "74HC08" V 5820 2980 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 5750 2850 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC08D-653_C5593.pdf" H 5750 2850 50  0001 C CNN
F 4 "C5593" H 5750 2850 50  0001 C CNN "LCSC"
	4    5750 2850
	0    1    1    0   
$EndComp
Wire Wire Line
	2250 2450 2250 2600
Text HLabel 3900 2050 1    50   Input ~ 0
nI3
Text HLabel 4000 2050 1    50   Input ~ 0
Q2
Wire Wire Line
	4600 4050 5450 4050
Wire Wire Line
	3600 2600 3950 2600
Wire Wire Line
	3150 3150 3550 3150
Wire Wire Line
	3050 3150 2700 3150
Wire Wire Line
	3100 3600 3650 3600
Text HLabel 5100 2600 1    50   Input ~ 0
Q1nQ2
Wire Wire Line
	5450 3150 5750 3150
Wire Wire Line
	5050 3150 5350 3150
$Comp
L PB170:74HC08 U12
U 1 1 6029894F
P 5050 2850
F 0 "U12" V 5029 2980 50  0000 L CNN
F 1 "74HC08" V 5120 2980 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 5050 2850 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC08D-653_C5593.pdf" H 5050 2850 50  0001 C CNN
F 4 "C5593" H 5050 2850 50  0001 C CNN "LCSC"
	1    5050 2850
	0    1    1    0   
$EndComp
Text HLabel 5800 2600 1    50   Input ~ 0
nQ2
$Comp
L PB170:74HC08 U12
U 5 1 602D5A67
P 8700 2200
F 0 "U12" V 8333 2200 50  0000 C CNN
F 1 "74HC08" V 8424 2200 50  0000 C CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 8700 2200 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC08D-653_C5593.pdf" H 8700 2200 50  0001 C CNN
F 4 "C5593" H 8700 2200 50  0001 C CNN "LCSC"
	5    8700 2200
	0    1    1    0   
$EndComp
$Comp
L PB170:74HC32 S1
U 5 1 6034F116
P 8700 4800
F 0 "S1" V 8085 4800 50  0000 C CNN
F 1 "74HC32" V 8176 4800 50  0000 C CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 8150 5000 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC32D-653_C5632.pdf" H 8150 5000 50  0001 C CNN
F 4 "C5632" H 8700 4800 50  0001 C CNN "LCSC"
	5    8700 4800
	0    1    1    0   
$EndComp
Wire Wire Line
	8200 3600 8350 3600
Wire Wire Line
	8200 2200 8200 2950
Connection ~ 8200 2950
Wire Wire Line
	8200 2950 8200 3600
Wire Wire Line
	8200 3600 8200 4500
Wire Wire Line
	8200 4500 8350 4500
Connection ~ 8200 3600
Wire Wire Line
	9050 4500 9200 4500
Wire Wire Line
	9200 4500 9200 3600
Connection ~ 9200 2950
Wire Wire Line
	9200 2950 9200 2200
Wire Wire Line
	9050 3600 9200 3600
Connection ~ 9200 3600
Wire Wire Line
	9200 3600 9200 2950
Text GLabel 8200 3250 0    50   Input ~ 0
GND
Text GLabel 9200 3250 2    50   Input ~ 0
VCC
Text HLabel 2750 2600 1    50   Input ~ 0
nI2I3
Wire Wire Line
	3150 2600 3500 2600
Text HLabel 5000 2600 1    50   Input ~ 0
nI2I3
Wire Wire Line
	5500 3600 6350 3600
Text HLabel 6300 3050 1    50   Input ~ 0
nI1I2
Text HLabel 6400 3050 1    50   Input ~ 0
nQ1Q2
Text HLabel 5700 2600 1    50   Input ~ 0
I1I2
$EndSCHEMATC
