EESchema Schematic File Version 4
EELAYER 30 0
EELAYER END
$Descr A4 11693 8268
encoding utf-8
Sheet 7 7
Title ""
Date ""
Rev ""
Comp ""
Comment1 ""
Comment2 ""
Comment3 ""
Comment4 ""
$EndDescr
$Comp
L 74xx:74HC74 U?
U 1 1 602EA5AC
P 2050 2650
AR Path="/602EA5AC" Ref="U?"  Part="1" 
AR Path="/602DED64/602EA5AC" Ref="U6"  Part="1" 
F 0 "U6" H 2050 3131 50  0000 C CNN
F 1 "74HC74" H 2050 3040 50  0000 C CNN
F 2 "PB170:TSSOP-14_L5.0-W4.4-P0.65-LS6.4-BL" H 2050 2650 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Texas-Instruments-TI-SN74HC74PWR_C6761.pdf" H 2050 2650 50  0001 C CNN
F 4 "C6761" H 2050 2650 50  0001 C CNN "LCSC"
	1    2050 2650
	1    0    0    -1  
$EndComp
$Comp
L 74xx:74HC74 U?
U 2 1 602EA5B3
P 3650 2650
AR Path="/602EA5B3" Ref="U?"  Part="2" 
AR Path="/602DED64/602EA5B3" Ref="U6"  Part="2" 
F 0 "U6" H 3650 3131 50  0000 C CNN
F 1 "74HC74" H 3650 3040 50  0000 C CNN
F 2 "PB170:TSSOP-14_L5.0-W4.4-P0.65-LS6.4-BL" H 3650 2650 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Texas-Instruments-TI-SN74HC74PWR_C6761.pdf" H 3650 2650 50  0001 C CNN
F 4 "C6761" H 3650 2650 50  0001 C CNN "LCSC"
	2    3650 2650
	1    0    0    -1  
$EndComp
$Comp
L PB170:74HC32 U?
U 1 1 602EA5BA
P 1450 2000
AR Path="/602EA5BA" Ref="U?"  Part="1" 
AR Path="/602DED64/602EA5BA" Ref="U3"  Part="1" 
F 0 "U3" V 1379 2138 50  0000 L CNN
F 1 "74HC32" V 1470 2138 50  0000 L CNN
F 2 "PB170:TSSOP-14_L5.0-W4.4-P0.65-LS6.4-BL" H 900 2200 50  0001 C CNN
F 3 "74xx/74hc_hct74.pdf" H 900 2200 50  0001 C CNN
F 4 "C5632" H 1450 2000 50  0001 C CNN "LCSC"
	1    1450 2000
	0    1    1    0   
$EndComp
$Comp
L PB170:74HC32 U?
U 2 1 602EA5C1
P 3100 2000
AR Path="/602EA5C1" Ref="U?"  Part="2" 
AR Path="/602DED64/602EA5C1" Ref="U3"  Part="2" 
F 0 "U3" V 3029 2138 50  0000 L CNN
F 1 "74HC32" V 3120 2138 50  0000 L CNN
F 2 "PB170:TSSOP-14_L5.0-W4.4-P0.65-LS6.4-BL" H 2550 2200 50  0001 C CNN
F 3 "74xx/74hc_hct74.pdf" H 2550 2200 50  0001 C CNN
F 4 "C5632" H 3100 2000 50  0001 C CNN "LCSC"
	2    3100 2000
	0    1    1    0   
$EndComp
Wire Wire Line
	1750 2550 1450 2550
Wire Wire Line
	1450 2550 1450 2200
Wire Wire Line
	3100 2200 3100 2550
Wire Wire Line
	3100 2550 3350 2550
$Comp
L PB170:74HC08 U?
U 1 1 602EA5CC
P 1150 1450
AR Path="/602EA5CC" Ref="U?"  Part="1" 
AR Path="/602DED64/602EA5CC" Ref="U4"  Part="1" 
F 0 "U4" V 1129 1580 50  0000 L CNN
F 1 "74HC08" V 1220 1580 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 1150 1450 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC08D-653_C5593.pdf" H 1150 1450 50  0001 C CNN
F 4 "C5593" H 1150 1450 50  0001 C CNN "LCSC"
	1    1150 1450
	0    1    1    0   
$EndComp
$Comp
L PB170:74HC08 U?
U 2 1 602EA5D3
P 1750 1450
AR Path="/602EA5D3" Ref="U?"  Part="2" 
AR Path="/602DED64/602EA5D3" Ref="U4"  Part="2" 
F 0 "U4" V 1729 1580 50  0000 L CNN
F 1 "74HC08" V 1820 1580 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 1750 1450 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC08D-653_C5593.pdf" H 1750 1450 50  0001 C CNN
F 4 "C5593" H 1750 1450 50  0001 C CNN "LCSC"
	2    1750 1450
	0    1    1    0   
$EndComp
Wire Wire Line
	1150 1750 1400 1750
Wire Wire Line
	1500 1750 1750 1750
Wire Wire Line
	2350 2550 2350 1050
Wire Wire Line
	2350 1050 1800 1050
Wire Wire Line
	1800 1050 1800 1200
Wire Wire Line
	3950 2750 4350 2750
Wire Wire Line
	4350 2750 4350 1150
Wire Wire Line
	1700 950  1700 1200
Wire Wire Line
	2350 2750 2600 2750
Wire Wire Line
	2600 2750 2600 1150
Wire Wire Line
	2600 1150 1200 1150
Wire Wire Line
	1200 1150 1200 1200
Wire Wire Line
	3950 2550 4050 2550
Wire Wire Line
	4050 850  1100 850 
Wire Wire Line
	1100 850  1100 1200
Wire Wire Line
	1750 1750 3050 1750
Connection ~ 1750 1750
Wire Wire Line
	4050 850  4050 2550
$Comp
L PB170:74HC08 U?
U 3 1 602EA5EC
P 3450 1450
AR Path="/602EA5EC" Ref="U?"  Part="3" 
AR Path="/602DED64/602EA5EC" Ref="U4"  Part="3" 
F 0 "U4" V 3429 1580 50  0000 L CNN
F 1 "74HC08" V 3520 1580 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 3450 1450 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC08D-653_C5593.pdf" H 3450 1450 50  0001 C CNN
F 4 "C5593" H 3450 1450 50  0001 C CNN "LCSC"
	3    3450 1450
	0    1    1    0   
$EndComp
Wire Wire Line
	3400 1200 3400 1150
Wire Wire Line
	3400 1150 2600 1150
Connection ~ 2600 1150
Wire Wire Line
	3500 1200 3500 1150
Wire Wire Line
	3500 1150 4350 1150
Wire Wire Line
	3150 1750 3450 1750
Wire Wire Line
	4350 950  4350 1150
Wire Wire Line
	1700 950  4350 950 
Connection ~ 4350 1150
$Comp
L 74xx:74HC74 U?
U 3 1 602EFAD5
P 7450 2850
AR Path="/602EFAD5" Ref="U?"  Part="3" 
AR Path="/602DED64/602EFAD5" Ref="U6"  Part="3" 
F 0 "U6" H 7680 2896 50  0000 L CNN
F 1 "74HC74" H 7680 2805 50  0000 L CNN
F 2 "PB170:TSSOP-14_L5.0-W4.4-P0.65-LS6.4-BL" H 7450 2850 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Texas-Instruments-TI-SN74HC74PWR_C6761.pdf" H 7450 2850 50  0001 C CNN
F 4 "C6761" H 7450 2850 50  0001 C CNN "LCSC"
	3    7450 2850
	0    -1   -1   0   
$EndComp
$Comp
L PB170:74HC32 U?
U 5 1 602EFADC
P 7400 1550
AR Path="/602EFADC" Ref="U?"  Part="5" 
AR Path="/602DED64/602EFADC" Ref="U3"  Part="5" 
F 0 "U3" H 6922 1504 50  0000 R CNN
F 1 "74HC32" H 6922 1595 50  0000 R CNN
F 2 "PB170:TSSOP-14_L5.0-W4.4-P0.65-LS6.4-BL" H 6850 1750 50  0001 C CNN
F 3 "74xx/74hc_hct74.pdf" H 6850 1750 50  0001 C CNN
F 4 "C5632" H 7400 1550 50  0001 C CNN "LCSC"
	5    7400 1550
	0    -1   -1   0   
$EndComp
$Comp
L PB170:74HC08 U?
U 5 1 602EFAE3
P 7400 1250
AR Path="/602EFAE3" Ref="U?"  Part="5" 
AR Path="/602DED64/602EFAE3" Ref="U4"  Part="5" 
F 0 "U4" H 7630 1296 50  0000 L CNN
F 1 "74HC08" H 7630 1205 50  0000 L CNN
F 2 "Housings_SOIC:SOIC-14_3.9x8.7mm_Pitch1.27mm" H 7400 1250 50  0001 C CNN
F 3 "https://datasheet.lcsc.com/szlcsc/Nexperia-74HC08D-653_C5593.pdf" H 7400 1250 50  0001 C CNN
F 4 "C5593" H 7400 1250 50  0001 C CNN "LCSC"
	5    7400 1250
	0    -1   -1   0   
$EndComp
Text HLabel 2350 2250 2    50   Input ~ 0
Q1
Text HLabel 2600 2250 2    50   Input ~ 0
nQ1
Text HLabel 4050 2250 2    50   Input ~ 0
Q2
Text HLabel 4350 2250 2    50   Input ~ 0
nQ2
Text HLabel 3250 1750 1    50   Input ~ 0
nQ1nQ2
Wire Wire Line
	6900 1250 6900 1850
Wire Wire Line
	6900 2850 7050 2850
Wire Wire Line
	7050 1850 6900 1850
Connection ~ 6900 1850
Wire Wire Line
	6900 1850 6900 2850
Wire Wire Line
	7900 1250 7900 1850
Wire Wire Line
	7900 2850 7850 2850
Wire Wire Line
	7750 1850 7900 1850
Connection ~ 7900 1850
Wire Wire Line
	7900 1850 7900 2850
Text GLabel 6900 2100 0    50   Input ~ 0
VCC
Text GLabel 7900 2100 2    50   Input ~ 0
GND
Text HLabel 1600 1750 1    50   Input ~ 0
Q1nQ2
Text HLabel 1250 1750 3    50   Input ~ 0
nQ1Q2
NoConn ~ 2050 2350
NoConn ~ 2050 2950
NoConn ~ 3650 2350
NoConn ~ 3650 2950
Wire Wire Line
	1750 2650 1750 3050
Wire Wire Line
	1750 3050 3350 3050
Wire Wire Line
	3350 3050 3350 2650
$EndSCHEMATC
